# Integridade e IA na Pesquisa
**Uma skill do Cefor/Ifes para mestrandos e doutorandos**

## Em uma frase

Esta skill ajuda você a usar IA na pesquisa **sem medo e sem atalho**, de acordo com a Portaria CNPq nº 2.664/2026.

## Por que isso importa agora

Desde março de 2026, a Política de Integridade do CNPq diz três coisas sobre IA:

1. **Pode usar**, mas é preciso **declarar** qual ferramenta e para quê, em qualquer fase da pesquisa. Vale também para slides e pôsteres.
2. **Não pode** apresentar conteúdo gerado por IA como se fosse escrito por você.
3. **Você responde por tudo**, inclusive pelos erros da IA, como referências que não existem.

Ninguém lembra, na hora de depositar, o que usou dois anos antes. A skill resolve isso.

## As 4 perguntas que a skill responde

| Você pergunta | A skill entrega |
|---|---|
| **1. Posso usar IA nisso?** | Um semáforo: 🟢 pode, 🟡 pode com cuidados, 🔴 não faça. Com o artigo da portaria e o jeito certo de fazer. |
| **2. Como registro o que usei?** | Um diário simples, de 5 campos, que fica com você. |
| **3. Como declaro?** | A declaração pronta, feita a partir do diário, para dissertação, tese, artigo, relatório ou slides. |
| **4. Posso entregar tranquilo?** | Uma checagem de citações, referências, dados e autoria, com o que resolver primeiro. |
| **Socorro: usei e não declarei** | O caminho para corrigir, conforme a etapa em que você está, sem pânico. |

## Como instalar (uma vez só, pelo computador)

1. Baixe o arquivo **integridade-ia-pesquisa.zip** e **não descompacte**. Se o computador descompactar sozinho (comum no Mac), compacte a pasta de novo.
2. Entre em **claude.ai**. Funciona também na conta gratuita.
3. Nas configurações, confirme que a **execução de código** está ativada. As skills dependem dela.
4. Vá em **Personalizar (Customize) > Skills**, clique em **+**, escolha **criar skill** e envie o arquivo .zip.
5. Confira se a skill aparece ativada na lista.

Os nomes dos menus podem mudar. Em caso de dúvida, procure por "skills" em support.claude.com.

## Teste agora (copie e cole no Claude)

- "Posso usar IA para transcrever as entrevistas da minha pesquisa?"
- "Ontem usei o ChatGPT para revisar o resumo da minha dissertação. Registra isso no meu diário."
- "Quero minha declaração de uso de IA para a dissertação."
- "Vou submeter um artigo semana que vem. Faz a checagem de integridade comigo."
- "A portaria do CNPq vale para mim se eu não tenho bolsa?"

Não precisa chamar a skill pelo nome: basta falar de IA na sua pesquisa. Se quiser garantir, comece com "Use a skill de integridade e IA na pesquisa".

## O que ela não faz

- Não escreve o trabalho para você esconder o uso de IA.
- Não "humaniza" texto para enganar detector.
- Não diz se um texto foi feito por IA.
- Não substitui orientador, coordenação, CEP ou PRPPG.
- Não guarda seus dados: o diário fica com você.

## Cuidado com dados

Nunca cole em ferramenta de IA, nem nesta skill, dados que identifiquem participantes da sua pesquisa. Anonimize antes, e só com amparo no TCLE.

## 3 regras para levar

1. IA pode ajudar em qualquer fase. Esconder, não.
2. O que a IA disser, você confere. O que entrar no trabalho, você responde.
3. Na dúvida: registre, declare e converse com seu orientador.

## Não usa o Claude?

Dentro do .zip, na pasta **assets**, estão o Diário de Uso de IA (texto e planilha) e o Plano de Uso de IA para combinar com o orientador. Eles funcionam em qualquer editor ou planilha, com qualquer ferramenta de IA.

---

Cefor/Ifes · Versão 1.0 · Setembro de 2026 · Base: Portaria CNPq nº 2.664/2026
